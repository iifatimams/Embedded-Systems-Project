/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "adc.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "lcd_i2c.h"
#include <string.h>
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

typedef enum {
    RFID_STATUS_NONE = 0,
    RFID_STATUS_ALLOWED,
    RFID_STATUS_DENIED,
    RFID_STATUS_POLICE
} RFID_Status;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define PARKING_THRESHOLD 7.0f
#define PARKING_THRESHOLD2 7.0f
#define TOTAL_SLOTS 6
#define FIXED_OCCUPIED 4

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
extern volatile int available_slots;
extern volatile uint8_t slot1_occupied;
extern volatile uint8_t slot2_occupied;
extern volatile uint8_t siren_active;
extern volatile uint32_t siren_start_time;
extern volatile uint8_t crash_lock;
extern volatile uint32_t crash_inhibit_until;   // in ms, HAL_GetTick() time


// Extern functions from main.c
RFID_Status RFID_CheckCard(void);
uint32_t measure_echo_us1(void);
uint32_t measure_echo_us2(void);
void gate_open(void);
void gate_close(void);
void siren_update(TIM_HandleTypeDef *htim, uint32_t Channel);

osThreadId_t ultrasonicTaskHandle;
osThreadId_t rfidTaskHandle;
osThreadId_t crashTaskHandle;
osThreadId_t SirenTaskHandle;

const osThreadAttr_t ultrasonicTask_attributes = {
  .name = "ultrasonicTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

const osThreadAttr_t rfidTask_attributes = {
  .name = "rfidTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

const osThreadAttr_t crashTask_attributes = {
  .name = "crashTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityAboveNormal,
};

const osThreadAttr_t SirenTask_attributes = {
  .name = "SirenTask",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 128 * 4   // same style as Cube MX
};

/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
void TaskUltrasonic(void *argument);
void TaskRFID_LCD_Gate(void *argument);
void TaskCrash(void *argument);
void TaskSiren(void *argument);

void DWT_Delay_us(uint32_t us);
/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  ultrasonicTaskHandle = osThreadNew(TaskUltrasonic, NULL, &ultrasonicTask_attributes);
  rfidTaskHandle       = osThreadNew(TaskRFID_LCD_Gate, NULL, &rfidTask_attributes);
  crashTaskHandle      = osThreadNew(TaskCrash, NULL, &crashTask_attributes);
  SirenTaskHandle = osThreadNew(TaskSiren, NULL, &SirenTask_attributes);

  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END StartDefaultTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
void TaskUltrasonic(void *argument)
{
  for (;;)
  {
    // --- Ultrasonic trigger 1 ---
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET);
    DWT_Delay_us(10);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET);

    uint32_t echo_time_us1 = measure_echo_us1();
    float distance1 = (echo_time_us1 * 0.0343f) / 2.0f;

    uint8_t new_slot1_occupied = (distance1 < PARKING_THRESHOLD) ? 1 : 0;

    if (new_slot1_occupied) {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_12, GPIO_PIN_RESET); // Green OFF
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);    // Red ON
    } else {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_12, GPIO_PIN_SET);   // Green ON
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_RESET);  // Red OFF
    }

    if (new_slot1_occupied != slot1_occupied) {
        if (new_slot1_occupied) available_slots--;
        else                     available_slots++;
        slot1_occupied = new_slot1_occupied;
    }

    // --- Ultrasonic trigger 2 ---
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
    DWT_Delay_us(10);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

    uint32_t echo_time_us2 = measure_echo_us2();
    float distance2 = (echo_time_us2 * 0.0343f) / 2.0f;

    uint8_t new_slot2_occupied = (distance2 < PARKING_THRESHOLD2) ? 1 : 0;

    if (new_slot2_occupied) {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET); // Green OFF
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);   // Red ON
    } else {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);   // Green ON
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET); // Red OFF
    }

    if (new_slot2_occupied != slot2_occupied) {
        if (new_slot2_occupied) available_slots--;
        else                     available_slots++;
        slot2_occupied = new_slot2_occupied;
    }

    // Clamp
    if (available_slots < 0)        available_slots = 0;
    if (available_slots > TOTAL_SLOTS) available_slots = TOTAL_SLOTS;

    osDelay(50);
  }
}

void TaskRFID_LCD_Gate(void *argument)
{
  for (;;)
  {
    // -------- Line 1: Always show available slots --------
    char line1[17];
    LCD_SetCursor(0, 0);
    snprintf(line1, sizeof(line1), "Available:%2d    ", available_slots);
    LCD_Print(line1);

    // Read card (if any)
    RFID_Status rstat = RFID_CheckCard();

    // =========================
    //      NORMAL MODE
    // =========================
    if (crash_lock == 0)
    {
        // Parking full → never open gate
        if (available_slots <= 0)
        {
            LCD_SetCursor(1, 0);
            LCD_Print("Parking full    ");
            gate_close();
        	if (rstat == RFID_STATUS_POLICE) {
        		// Police clears the accident
        		LCD_SetCursor(1, 0);
        		LCD_Print("Police access   ");

        		gate_open();
        		osDelay(2500);
        		gate_close();

        		// Clear accident state
        		crash_lock     = 0;
        		siren_active   = 0;
        		HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_4);
        		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);

        		// Back to normal default message
        		LCD_SetCursor(1, 0);
        		LCD_Print("Parking full    ");
        	}
        }
        else
        {
            // available_slots > 0 here

            if (rstat == RFID_STATUS_ALLOWED)
            {
                // Extra safety: check again
                if (available_slots > 0)
                {
                    LCD_SetCursor(1, 0);
                    LCD_Print("Access granted  ");

                    gate_open();
                    osDelay(2500);
                    gate_close();
                }
                else
                {
                    LCD_SetCursor(1, 0);
                    LCD_Print("Parking full    ");
                    gate_close();
                }
            }
            else if (rstat == RFID_STATUS_POLICE)
            {
                // Same rule: only open if there is space
                if (available_slots > 0)
                {
                    LCD_SetCursor(1, 0);
                    LCD_Print("Police access   ");

                    gate_open();
                    osDelay(2500);
                    gate_close();
                }
                else
                {
                    LCD_SetCursor(1, 0);
                    LCD_Print("Parking full    ");
                    gate_close();
                }
            }
            else if (rstat == RFID_STATUS_DENIED)
            {
                LCD_SetCursor(1, 0);
                LCD_Print("Access denied   ");
                osDelay(2500);
                gate_close();
            }
            else // RFID_STATUS_NONE
            {
                LCD_SetCursor(1, 0);
                LCD_Print("Show Card....   ");
                gate_close();
            }
        }
    }
    // =========================
    //      ACCIDENT MODE
    // =========================
    else  // crash_lock == 1
    {
        /*
         * Rules you gave:
         * - If Accident: keep second line on "Accident"
         * - If user / non-user: "Accident! Stop"
         * - If police: "Police Access" and then back to "Show Card",
         *   also reopen system (clear accident).
         */

        if (rstat == RFID_STATUS_POLICE)
        {
            // Police clears the accident
            LCD_SetCursor(1, 0);
            LCD_Print("Police access   ");

            gate_open();
            osDelay(2500);
            gate_close();

            // Clear accident state
            crash_lock     = 0;
            siren_active   = 0;
            HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_4);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);

            // Back to normal default message
            LCD_SetCursor(1, 0);
            LCD_Print("Show Card....   ");
        }
        else if (rstat == RFID_STATUS_ALLOWED || rstat == RFID_STATUS_DENIED)
        {
            // Any non-police card during accident → warn and keep gate closed
            LCD_SetCursor(1, 0);
            LCD_Print("Accident! Stop  ");
            osDelay(2500);
            gate_close();
        }
        else // RFID_STATUS_NONE
        {
            // No card during accident: keep showing "Accident" and keep gate closed
            LCD_SetCursor(1, 0);
            LCD_Print("Accident        ");
            gate_close();
        }
    }

    osDelay(100);
  }
}

void TaskSiren(void *argument)
{
  for (;;)
  {
    siren_update(&htim1, TIM_CHANNEL_4);
    osDelay(5);   // 5–10 ms is fine
  }
}


void TaskCrash(void *argument)
{
  for (;;)
  {
    uint32_t now = HAL_GetTick();

    // 🔇 1) MUTE crash detection while:
    //    - servo has just moved (crash_inhibit_until in future), OR
    //    - siren is active
    if ((now < crash_inhibit_until) || (siren_active == 1))
    {
        HAL_ADC_Start(&hadc1);
        if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK)
        {
            uint32_t sound_value = HAL_ADC_GetValue(&hadc1);
            printf("Sound (muted): %lu\r\n", sound_value);
        }

        osDelay(25);
        continue;
    }


    // 🔊 2) Normal crash detection logic
    HAL_ADC_Start(&hadc1);

    if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK)
    {
        uint32_t sound_value = HAL_ADC_GetValue(&hadc1);
        printf("Sound: %lu\r\n", sound_value);

        // Crash condition: ONE reading between 70 and 130
        if (!crash_lock && sound_value > 145 && sound_value < 190)
        {
            crash_lock = 1;

            if (siren_active == 0)
            {
                siren_active = 1;
                siren_start_time = HAL_GetTick();

                HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
                HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);

                const char crash_msg[] = "CRASH\n";
                HAL_UART_Transmit(&huart3, (uint8_t*)crash_msg, strlen(crash_msg), 100);
            }

            gate_close();   // this also sets crash_inhibit_until in your gate_close()
        }
    }

    osDelay(25);
  }
}




/* USER CODE END Application */

