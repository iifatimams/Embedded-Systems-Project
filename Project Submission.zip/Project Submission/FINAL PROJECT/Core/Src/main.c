/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "adc.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>   // for sprintf
#include "lcd_i2c.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define PARKING_THRESHOLD 7.0 // Threshold distance in cm to determine if parking is occupied
#define PARKING_THRESHOLD2 7.0 // Threshold distance in cm to determine if parking is occupied
#define SIREN_DURATION_MS   5000   // siren ON time = 5 seconds

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

// Parking logic
#define TOTAL_SLOTS 6
#define FIXED_OCCUPIED 4

volatile int available_slots = TOTAL_SLOTS - FIXED_OCCUPIED;
volatile uint8_t slot1_occupied = 0;
volatile uint8_t slot2_occupied = 0;

volatile uint8_t siren_active = 0;
volatile uint32_t siren_start_time = 0;
volatile uint32_t crash_inhibit_until = 0;   // in ms, HAL_GetTick() time



volatile uint8_t crash_lock = 0;   // 0 = normal, 1 = accident mode

//RFID
#define RFID_FRAME_LEN 12      // enough for ID + checksum + CR/LF/whatever

uint8_t rfid_raw[RFID_FRAME_LEN + 1];   // buffer for raw UART frame
char    rfid_id[11];                    // 10 chars + null terminator

// Add your future allowed card IDs here
const char ALLOWED_CARD_USER_1[] = "5200129DAB";
const char ALLOWED_CARD_USER_2[] = "5200127111";
const char ALLOWED_CARD_POLICE[] = "5300C81225"; // police card
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void MX_FREERTOS_Init(void);
/* USER CODE BEGIN PFP */
// ultrasonic
void DWT_Init(void);
void DWT_Delay_us(uint32_t us);
uint32_t measure_echo_us1(void);
uint32_t measure_echo_us2(void);

// servo motor
void servo_set_us(uint16_t pulse_us);
void gate_open();
void gate_close();

//crash detection
int _write(int file, char *ptr, int len);
void siren_update(TIM_HandleTypeDef *htim, uint32_t Channel);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// ultrasonic
void DWT_Init(void)
{
    // Enable DWT
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

void DWT_Delay_us(uint32_t us)
{
    uint32_t cycles = (SystemCoreClock / 1000000U) * us;
    uint32_t start = DWT->CYCCNT;
    while ((DWT->CYCCNT - start) < cycles);
}

uint32_t measure_echo_us1(void)
{
    uint32_t timeout = HAL_GetTick() + 10;  // 10 ms timeout

    // Wait for echo pin high (max 10 ms)
    while (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_8) == GPIO_PIN_RESET)
    {
        if (HAL_GetTick() > timeout)
            return 0;   // timeout, no echo
    }

    uint32_t start = DWT->CYCCNT;

    // Wait for echo pin low (another 10 ms)
    timeout = HAL_GetTick() + 10;
    while (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_8) == GPIO_PIN_SET)
    {
        if (HAL_GetTick() > timeout)
            break;   // stop waiting
    }

    uint32_t end = DWT->CYCCNT;
    return (end - start) / (SystemCoreClock / 1000000U);
}

uint32_t measure_echo_us2(void)
{
    uint32_t timeout = HAL_GetTick() + 10;  // 10 ms timeout

    while (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12) == GPIO_PIN_RESET)
    {
        if (HAL_GetTick() > timeout)
            return 0;  // timeout
    }

    uint32_t start = DWT->CYCCNT;

    timeout = HAL_GetTick() + 10;
    while (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12) == GPIO_PIN_SET)
    {
        if (HAL_GetTick() > timeout)
            break;
    }

    uint32_t end = DWT->CYCCNT;
    return (end - start) / (SystemCoreClock / 1000000U);
}

// servo motor
void servo_set_us(uint16_t pulse_us) {
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, pulse_us);
}

void gate_open() {
    servo_set_us(2000); // ~2 ms pulse → open
    crash_inhibit_until = HAL_GetTick() + 4500;   // ignore crashes for 1s
}

void gate_close() {
    servo_set_us(1000); // ~1.0 ms pulse → close
}

//RFID
typedef enum {
    RFID_STATUS_NONE = 0,   // no card / timeout
    RFID_STATUS_ALLOWED,    // user card in allowed list
    RFID_STATUS_DENIED,     // card read but not allowed
    RFID_STATUS_POLICE      // police card
} RFID_Status;

// RFID: read card and return status (no prints, no gate here)
RFID_Status RFID_CheckCard(void)
{
    if (HAL_UART_Receive(&huart1, rfid_raw, RFID_FRAME_LEN, 200) == HAL_OK)
    {
        rfid_raw[RFID_FRAME_LEN] = '\0';

        // Extract first "word" up to 10 chars
        sscanf((char*)rfid_raw, "%10s", rfid_id);
        rfid_id[10] = '\0';

        // 1) Check police card first
        if (strncmp(rfid_id, ALLOWED_CARD_POLICE, 10) == 0)
        {
            return RFID_STATUS_POLICE;
        }

        // 2) Check normal user cards
        if (strncmp(rfid_id, ALLOWED_CARD_USER_1, 10) == 0 ||
            strncmp(rfid_id, ALLOWED_CARD_USER_2, 10) == 0)
        {
            return RFID_STATUS_ALLOWED;
        }

        // 3) Unknown card
        return RFID_STATUS_DENIED;
    }
    else
    {
        return RFID_STATUS_NONE; // no card / timeout
    }
}

//crash detection
int _write(int file, char *ptr, int len)
{
    HAL_UART_Transmit(&huart2, (uint8_t*)ptr, len, HAL_MAX_DELAY);
    return len;
}

void siren_update(TIM_HandleTypeDef *htim, uint32_t Channel)
{
    static uint32_t last_step = 0;
    static int freq = 400;      // start low
    static int step = 10;       // step size: controls speed of "wowow"

    uint32_t now = HAL_GetTick();

    // 1) If siren is not active, make sure it is OFF and return
    if (!siren_active)
    {
        HAL_TIM_PWM_Stop(htim, Channel);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);  // siren GPIO low
        return;
    }

    // 2) Auto-stop after duration
    if (now - siren_start_time >= SIREN_DURATION_MS)
    {
        siren_active = 0;
        HAL_TIM_PWM_Stop(htim, Channel);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
        return;
    }

    // 3) Normal frequency sweep while active
    if (now - last_step < 10) return; // update every 10ms
    last_step = now;

    // Sweep freq: 400 → 1600 → 400 → ...
    freq += step;

    if (freq > 1600) step = -10;   // reverse direction at top
    if (freq < 400)  step = +10;   // reverse direction at bottom

    // Apply frequency to PWM (assuming 1 MHz timer clock)
    uint32_t arr = 1000000 / freq;
    __HAL_TIM_SET_AUTORELOAD(htim, arr - 1);
    __HAL_TIM_SET_COMPARE(htim, Channel, arr / 2);
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  DWT_Init();   // needed for DWT_Delay_us()
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  LCD_Init();

  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_SET);    // PC9 ON "GREEN"
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET);  // PB6 OFF

  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);   // Start PWM for servo

  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);  // ENABLE = High

  gate_close();

  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);   // Start PWM for servo
  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();  /* Call init function for freertos objects (in cmsis_os2.c) */
  MX_FREERTOS_Init();

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */


  } // closing while(1)
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
